<?php 
/**
 * Proper way to enqueue scripts and styles
 */


// for adding style and js 

function wpdocs_theme_name_scripts() {
   wp_enqueue_style( 'style', get_stylesheet_uri() );
   wp_enqueue_style('bootstrap.min', get_stylesheet_directory_uri(). '/assets/css/bootstrap.min.css');
   wp_enqueue_style('slick', get_stylesheet_directory_uri(). '/assets/css/slick/slick.css');
   wp_enqueue_style('slick-theme', get_stylesheet_directory_uri(). '/assets/css/slick/slick-theme.css');
   wp_enqueue_script( 'jquery-2.2.0.min', get_template_directory_uri() . '/assets/js/jquery-2.2.0.min.js', array(), '2.2.0', true );
   wp_enqueue_script( 'slick.min', get_template_directory_uri() . '/assets/css/slick/slick.min.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );
// for adding thumbnails

add_theme_support( 'post-thumbnails' );

// for adding movie custom post type in admin 

function my_custom_post_movie() {
    $args = array();
    $labels = array(
        'name'               => _x( 'Movies', 'post type general name' ),
        'singular_name'      => _x( 'Movie', 'post type singular name' ),
        'add_new'            => _x( 'Add New', 'Movie' ),
        'add_new_item'       => __( 'Add New Movie' ),
        'edit_item'          => __( 'Edit Movie' ),
        'new_item'           => __( 'New Movie' ),
        'all_items'          => __( 'All Movies' ),
        'view_item'          => __( 'View Movie' ),
        'search_items'       => __( 'Search Movies' ),
        'not_found'          => __( 'No movies found' ),
        'not_found_in_trash' => __( 'No movies found in the Trash' ),
        'parent_item_colon'  => '',
        'menu_name'          => 'Movies'
      );

    $args = array(
        'labels'        => $labels,
        'description'   => 'Displays city movies and their ratings',
        'public'        => true,
        'menu_position' => 3,
        'supports'      => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'has_archive'   => true,
        'taxonomies'    => array( 'category', 'post_tag' ),
      );
    register_post_type( 'movie', $args );
  }
  add_action( 'init', 'my_custom_post_movie' );

//adding meta field in movies 

function add_your_fields_meta_box() {
   
	add_meta_box(
		'director', // $id
		'Director', // $title
		'show_your_fields_meta_box', // $callback
		'movie', // $screen
		'normal', // $context
		'high' // $priority
    );
    
}
add_action( 'add_meta_boxes', 'add_your_fields_meta_box' );


function show_your_fields_meta_box() {
	global $post;  
  $director = get_post_meta( $post->ID, 'director', true );
  
  $args = array( 'post_type' => 'director' );
  $the_query = new WP_Query( $args );

  echo '<select name="director_meta_box_value">';
  
  
  if ( $the_query->have_posts() ) {

    while ( $the_query->have_posts() ) {
              $the_query->the_post();
              echo $title = get_the_title();
    ?>
    <option value="<?php echo $title; ?>" <?php if($director == $title){ echo 'selected'; } ?>> <?php echo $title; ?></option>;
        
<?php
    }

  } 
  echo '</select>';
	//echo '<input type="text" name="director_meta_box_value" value="' . $director . '">';

} 
    
function save_your_fields_meta( $post_id ) {
    $director = $_POST['director_meta_box_value'];
    update_post_meta( $post_id, 'director', $director );
 }
add_action( 'save_post', 'save_your_fields_meta' );

// register menu setuping

add_action( 'after_setup_theme', 'register_my_menu' );
function register_my_menu() {
  register_nav_menu( 'primary-menu', __( 'Primary Menu', 'primary' ) );
  register_nav_menu( 'footer-menu', __( 'Footer Menu', 'footer' ) );
  register_nav_menu( 'side-menu', __( 'Side Menu', 'side' ) );
}

// adding css class to a in menu 

function add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_link_atts');


// adding director custom post type

 function my_custom_post_director() {
  $args = array();
  $labels = array(
      'name'               => _x( 'Directors', 'post type general name' ),
      'singular_name'      => _x( 'Director', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'Director' ),
      'add_new_item'       => __( 'Add New Director' ),
      'edit_item'          => __( 'Edit Director' ),
      'new_item'           => __( 'New Director' ),
      'all_items'          => __( 'All Directors' ),
      'view_item'          => __( 'View Director' ),
      'search_items'       => __( 'Search Directors' ),
      'not_found'          => __( 'No directors found' ),
      'not_found_in_trash' => __( 'No directors found in the Trash' ),
      'parent_item_colon'  => '',
      'menu_name'          => 'Directors'
    );

  $args = array(
      'labels'        => $labels,
      'description'   => 'Displays city directors and their ratings',
      'public'        => true,
      'menu_position' => 3,
      'supports'      => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
      'taxonomies'    => array( 'category', 'post_tag' ),
    );
  register_post_type( 'director', $args );
}
add_action( 'init', 'my_custom_post_director' );

// adding director column in movie 

function movie_columns( $columns ) {

  // New columns to add to table
  $new_columns = array(
	'director' => __( 'Directors', 'myplugin_textdomain' ),
  );
	
  // Remove unwanted publish date column
  unset( $columns['date'] );
  
  // Combine existing columns with new columns
  $filtered_columns = array_merge( $columns, $new_columns );

  // Return our filtered array of columns
  return $filtered_columns;
}

// retreiving data for director in movies post type

// Let WordPress know to use our filter
add_filter('manage_movie_posts_columns' , 'movie_columns');

function myplugin_event_custom_column_content( $column ) {
  
  // Get the post object for this row so we can output relevant data
  global $post;


  
  // Check to see if $column matches our custom column names
  switch ( $column ) {

    case 'director' :
      // Retrieve post meta
      $director = get_post_meta( $post->ID, 'director', true );
      
      // Echo output and then include break statement
      //echo $director;
      break;

   
      
  }
}

// Let WordPress know to use our action
add_action( 'manage_movie_posts_custom_column', 'myplugin_event_custom_column_content' );


// adding quick edit

add_action( 'manage_movie_posts_custom_column', 'columns_content', 10, 2 );
 
/**
 * Set content for columns in management page
 *
 * @param string $column_name
 * @param int $post_id
 *
 * @return void
 */
function columns_content( $column_name, $post_id )
{
	if ( 'director' != $column_name )
	{
		return;
	}
	$directors = get_post_meta( $post_id, 'director', true );
	echo $directors;
}

add_action( 'quick_edit_custom_box', 'quick_edit_add', 10, 2 );
 
/**
 * Add Headline news checkbox to quick edit screen
 *
 * @param string $column_name Custom column name, used to check
 * @param string $post_type
 *
 * @return void
 */
function quick_edit_add( $column_name, $post_type )
{
	if ( 'director' != $column_name )
	{
		return;
  }

  global $post;
  
  $director = get_post_meta( $post->ID, 'director', true );

  

  $args = array( 'post_type' => 'director' );
  $the_query = new WP_Query( $args );

  
  echo '<select name="director_meta_box_value">';
  
  
  if ( $the_query->have_posts() ) {

    while ( $the_query->have_posts() ) {
              $the_query->the_post();
              echo $title = get_the_title();
    ?>
    <option value="<?php echo $title; ?>" <?php if($director == $title){ echo 'selected'; } ?>> <?php echo $title; ?></option>;
        
<?php
    }

  } 
  echo '</select>';
  
}


add_action( 'save_post', 'save_quick_edit_data' );
 
/**
 * Save quick edit data
 *
 * @param int $post_id
 *
 * @return void|int
 */
function save_quick_edit_data( $post_id )
{
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	{
		return $post_id;
	}
 
	if ( ! current_user_can( 'edit_post', $post_id ) || 'post' != $_POST['post_type'] )
	{
		return $post_id;
	}
 
	$data = empty( $_POST['director'] ) ? 0 : 1;
	update_post_meta( $post_id, 'director', $data );
}


// adding widget to the area

function wpb_widgets_init() {
 
  register_sidebar( array(
      'name' => __( 'Main Sidebar', 'wpb' ),
      'id' => 'sidebar-1',
      'description' => __( 'The main sidebar appears on the right on each page except the front page template', 'wpb' ),
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget' => '</aside>',
      'before_title' => '<h3 class="widget-title">',
      'after_title' => '</h3>',
  ) );

  register_sidebar( array(
      'name' =>__( 'Front page sidebar', 'wpb'),
      'id' => 'sidebar-2',
      'description' => __( 'Appears on the static front page template', 'wpb' ),
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget' => '</aside>',
      'before_title' => '<h3 class="widget-title">',
      'after_title' => '</h3>',
  ) );
  }

add_action( 'widgets_init', 'wpb_widgets_init' );



?>

<?php
//  Sample widgets form,update,widget
/*
Plugin Name: Sample Wordpress Widget
Plugin URI: https://timtrott.co.uk/
Version: 1.0
Description: How to create a Wordpress Widget
Author: Tim Trott
Author URI: https://timtrott.co.uk/
*/
 
class Sample_Widget extends WP_Widget
{
  function Sample_Widget()
  {
    $widget_ops = array('classname' => 'Sample_Widget', 'description' => 'My Sample Widget Description');
    $this->WP_Widget('Sample_Widget', 'My Sample Widget', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args((array) $instance, array( 'title' => '' ));
    $title = $instance['title'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
 
    if (!empty($title))
      echo $before_title . $title . $after_title;;
 
    // Do Your Widgety Stuff Here...
    echo "<h1>Hello World</h1>";
 
    echo $after_widget;
  }
}
add_action( 'widgets_init', create_function('', 'return register_widget("Sample_Widget");') );
 
?>


<?php
//  Sample widgets form,update,widget
/*
Plugin Name: Sample Wordpress Widget
Plugin URI: https://timtrott.co.uk/
Version: 1.0
Description: How to create a Wordpress Widget
Author: Tim Trott
Author URI: https://timtrott.co.uk/
*/
 
class New_Widget extends WP_Widget
{
  function New_Widget()
  {
    $widget_ops = array('classname' => 'New_Widget', 'description' => 'My New Widget Description');
    $this->WP_Widget('New_Widget', 'My New Widget', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args((array) $instance, array( 'title' => '', 'description' => '', 'director' => '', 'posttype' => '' ));

    $director = get_post_meta( $post->ID, 'director', true );
    $args = array( 'post_type' => 'director' );
    $the_query = new WP_Query( $args );

   

    $title = $instance['title'];
    $description = $instance['description'];
    $director = $instance['director'];
    $posttype = $instance['posttype'];
    


    global $post;
  
    
   
    

?>

    
  



  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('description'); ?>">Description: <input class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" type="text" value="<?php echo attribute_escape($description); ?>" /></label></p>

<?php
echo '<select name="'.$this->get_field_name('posttype').'" id=""'.$this->get_field_id('posttype').'">';


$args = array(
  'public'   => true,
  '_builtin' => false
);

foreach ( get_post_types( $args, 'names' ) as $post_type ) {
  echo '<p>' . $post_type . '</p>';

  ?>
  <option value="<?php echo $post_type; ?>" <?php if($posttype == $post_type){ echo 'selected'; } ?>> <?php echo $post_type; ?></option>;
      <?php
  
} 
echo '</select>';


  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];

    $instance['description'] = $new_instance['description'];

    $instance['posttype'] = $new_instance['posttype'];
    
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);

    $description = empty($instance['description']) ? '' : apply_filters('description', $instance['description']);

    $posttype = empty($instance['posttype']) ? '' : apply_filters('posttype', $instance['posttype']);

    $args = array( 'post_type' => $posttype );
    $the_query = new WP_Query( $args );

    if (!empty($title))
      echo $before_title . $title .$after_title;

    if (!empty($description))
    echo $before_description . $description . $after_description;

    if (!empty($posttype)){

      if ( $the_query->have_posts() ) {
        echo '<div class="widget blog-widget" >';       
        while ( $the_query->have_posts() ) {
          $the_query->the_post();
    
            echo '<div class="ct-latest media" >';
            echo '<div class="media-left" >';
            echo  the_post_thumbnail('full', array( 'class'  => 'media-object', 'style' => 'max-width: 90px; user-select: auto;height: 70px;' ) );
            echo '</div>';
            echo '<div class="media-body" >';
            echo '<h2 class="ct-latest-header media-heading" ><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>';
            echo '<p>'.get_the_excerpt().'</p>';
            echo '</div>';
            echo '</div>';
            

         // echo '<li>' . get_the_title() . '</li>';
        }
        echo '</div>';
        /* Restore original Post Data */
        wp_reset_postdata();
      } else {
        // no posts found
      }


    }
    
       
 
    // Do Your Widgety Stuff Here...
    //echo "<h1>Hello World</h1>";
 
    echo $after_widget;
  }
}
add_action( 'widgets_init', create_function('', 'return register_widget("New_Widget");') );








// adding short codes

function quote( $atts, $content = null ) {
  return '<div class="right text">"'.$content.'"</div>';
}

add_shortcode("quote", "quote");

function random_picture($atts) {
  extract(shortcode_atts(array(
     'width' => 400,
     'height' => 200,
  ), $atts));
return '<img src="https://lorempixel.com/'. $width . '/'. $height . '" />';
}
add_shortcode('picture', 'random_picture');


function p_link($atts, $content = null) {
  extract(shortcode_atts(array(
      "to" => 'http://net.tutsplus.com'
  ), $atts));
  return '<a href="'.$to.'">'.$content.'</a>';
}

add_shortcode("link", "p_link");



// for adding songs custom post type in admin 

function my_custom_post_song() {
  $args = array();
  $labels = array(
      'name'               => _x( 'Songs', 'post type general name' ),
      'singular_name'      => _x( 'Song', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'Song' ),
      'add_new_item'       => __( 'Add New Song' ),
      'edit_item'          => __( 'Edit Song' ),
      'new_item'           => __( 'New Song' ),
      'all_items'          => __( 'All Songs' ),
      'view_item'          => __( 'View Song' ),
      'search_items'       => __( 'Search Songs' ),
      'not_found'          => __( 'No songs found' ),
      'not_found_in_trash' => __( 'No songs found in the Trash' ),
      'parent_item_colon'  => '',
      'menu_name'          => 'Songs'
    );

  $args = array(
      'labels'        => $labels,
      'description'   => 'Displays city songs and their ratings',
      'public'        => true,
      'menu_position' => 3,
      'supports'      => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
      'has_archive'   => true,
      'taxonomies'    => array( 'category', 'post_tag' ),
    );
  register_post_type( 'song', $args );
}
add_action( 'init', 'my_custom_post_song' );



function php_execute($html){
  if(strpos($html,"<"."?php")!==false){ ob_start(); eval("?".">".$html);
  $html=ob_get_contents();
  ob_end_clean();
  }
  return $html;
  }
  add_filter('widget_text','php_execute',100);

?>

 