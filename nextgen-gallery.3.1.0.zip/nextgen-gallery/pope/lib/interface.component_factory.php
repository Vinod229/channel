<?php

if (!defined('POPE_VERSION')) { die('Use autoload.php'); }

interface I_Component_Factory
{
    
}